import os
import shutil

from_dir = "C:\Users\tamir\Downloads"
to_dir = "C:\Users\tamir\OneDrive\Área de Trabalho\Arquivos_Documentos"

list_of_files = os.listdir(from_dir)
#print(list_of_files)
loop for in list_of_files():
os.path.splitext()
print(list_of_files)
